//
//  ReporterProtocol.h
//  MQIoTiOSSDK
//
//  Created by sehoward15 on 12/21/16.
//  Copyright © 2016 Mapquest. All rights reserved.
//

typedef NS_ENUM(NSUInteger, RegionBreachType) {
    RegionBreachTypeEnter,
    RegionBreachTypeExit,
    RegionBreachTypeBoth
};

@class MQIOObservation;
@protocol Reportable <NSObject>

- (void)reportObservations:(nonnull NSArray<MQIOObservation *> *)locations completion:(void (^ _Nullable)(id _Nullable, NSError * _Nullable))completion;
@property (nonatomic, assign) NSTimeInterval reportingInterval;

@end
