//
//  MQRegionManager.h
//  MQPlatformSDK
//
//  Created by sehoward15 on 2/8/17.
//  Copyright © 2017 Mapquest. All rights reserved.
//

#import <CoreLocation/CoreLocation.h>

@interface MQIORegionManager : NSObject

- (nonnull instancetype)initWithClientId:(nonnull NSString *)clientId clientSecret: (nonnull NSString *)clientSecret;

/**
 Adds a set of monitored regions to the current set.

 @param regions Set of regions to monitor. Regions that share the same `identifier` are replaced.
 */
+ (void)addRegions:(nonnull NSSet<CLCircularRegion *> *)regions;

/**
 Remove all monitored regions.
 */
+ (void)removeRegions;

/**
 Remove a monitored region.

 @param region Region to remove.
 */
- (void)removeRegion:(nonnull CLRegion *)region;

- (nonnull instancetype)init NS_UNAVAILABLE;

@end
