//
//  MQIOShare.h
//  MapQuestIO
//
//  Created by sehoward15 on 4/14/17.
//  Copyright © 2017 Mapquest. All rights reserved.
//

#import <Foundation/Foundation.h>


@class MQIOShareObserver, MQIOObservation, CLLocation;
@protocol MQIOShareDelegate <NSObject>

@optional

/**
 Called when a new event or event triggered from retrieving a set of observation (eg. when initializing) is found.

 @param mqIOShareObserver The current observer.
 @param observedEvent Observation with the observed event. Note that this event may have happened some time in the past. Check the observation's timestamp to know when.
 */
- (void)mqIOShareObserver:(nonnull MQIOShareObserver *)mqIOShareObserver receivedEvent:(nonnull MQIOObservation *)observedEvent;

/**
 Called when receiving new locations.

 @param mqIOShareObserver The current observer.
 @param locations A collection of locations. This is a current subset of all locations.
 */
- (void)mqIOShareObserver:(nonnull MQIOShareObserver *)mqIOShareObserver receivedLocations:(nonnull NSArray <CLLocation *> *)locations;

/**
 Called when the observer fails to connect with the API. When triggered shares stop polling.

 @param mqIOShareObserver The current observer.
 @param error Error describing what went wrong.
 */
- (void)mqIOShareObserver:(nonnull MQIOShareObserver *)mqIOShareObserver failedWithError:(nonnull NSError *)error;

@end


/**
 Creates an interface for handing observing a share session.
 */
@interface MQIOShareObserver : NSObject

/**
 Create a new share observer. No observations are returned until the delegate and start are called.

 @param shareId The share session Id to observe.
 @return Share observer.
 */
- (nonnull instancetype)initWithShareId:(nonnull NSString *)shareId;


/**
 Create a new share observer. No observations are returned until the delegate and start are called.

 @param shareId The share session Id to observe.
 @param date Date to start observations from. A long running session may include many data points, if they are not all needed pass the date from when to start for a smaller data set.
 @return Share observer.
 */
- (nonnull instancetype)initWithShareId:(nonnull NSString *)shareId startingFromDate:(NSDate *_Nullable)date;


/**
 Start polling for observations.
 */
- (void)start;


/**
 Stop polling for observations.
 */
- (void)stop;

/**
 All known locations up to this point.
 */
@property(nullable, readonly) NSArray<CLLocation *> *locations;

/**
 Share Id being observed.
 */
@property(nullable, readonly) NSString *shareId;

/**
 How often to pull down new observations. The lower the number the more battery usage. Default value is 60 seconds.
 */
@property(assign, nonatomic) NSTimeInterval pollingInterval;

/**
 MQIOShareDelege
 */
@property(nullable, weak, nonatomic) id<MQIOShareDelegate> delegate;

- (nonnull instancetype)init NS_UNAVAILABLE;

@end
