//
//  MQIOObservation.h
//  MapQuestIO
//
//  Created by sehoward15 on 4/7/17.
//  Copyright © 2017 Mapquest. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 Observation associated types that define an event.

 - MQIOEventTypeStartedRoute: Route has been started.
 - MQIOEventTypeCompletedRoute: Completed a route.
 - MQIOEventTypeAbandonedRoute: Abandoned a route.
 */
typedef NS_ENUM(NSUInteger, MQIOEventType) {
    MQIOEventTypeStartedRoute,
    MQIOEventTypeCompletedRoute,
    MQIOEventTypeAbandonedRoute
};

static inline NSString * _Nonnull MQIOEventTypeToString(MQIOEventType type) {
    switch (type) {
        case MQIOEventTypeStartedRoute:
            return @"startedroute";
        case MQIOEventTypeCompletedRoute:
            return @"completedroute";
        case MQIOEventTypeAbandonedRoute:
            return @"abandonedroute";
    }
}

@interface MQIOEvent : NSObject<NSCoding>


/**
 Creates an event.

 @param eventType The type of event.
 @param identifier Extra string data associated with the event.
 @return The Event.
 */
- (nonnull instancetype)initWithEventType:(MQIOEventType)eventType identifier:(nonnull NSString *)identifier;
- (nonnull instancetype)init NS_UNAVAILABLE;


/**
 The type of event.
 */
@property(readonly) MQIOEventType eventType;

/**
 Extra string data associated with the event.
 */
@property(nonnull, readonly) NSString *identifier;

/**
 Serializable format.
 */
@property(nonnull, readonly) NSDictionary *dictionary;

@end

@class CLLocation;

@interface MQIOObservation : NSObject<NSCoding>

/**
 Creates a location based observation.

 @param location Location of the observation.
 @return New observation.
 */
+ (nonnull instancetype)observationWithLocation:(nonnull CLLocation *)location;

/**
 Creates a location based observation.
 
 @param location Location of the observation.
 @return New observation.
 */
- (nonnull instancetype)initWithLocation:(nonnull CLLocation *)location;


/**
 Creates a location based observation with a cooresponding event.

 @param location Location of the observation.
 @param event Event associated to the observations.
 @return New observation.
 */
- (nonnull instancetype)initWithLocation:(nonnull CLLocation *)location event:(nullable MQIOEvent *)event;
- (nonnull instancetype)init NS_UNAVAILABLE;


/**
 The obervation's associated event.
 */
@property(nullable, readonly) MQIOEvent *event;

/**
 Serializable format.
 */
@property(nonnull, readonly) NSDictionary *dictionary;

/**
 The observation's associated location.
 */
@property (nullable, readonly) CLLocation *location;

@end

