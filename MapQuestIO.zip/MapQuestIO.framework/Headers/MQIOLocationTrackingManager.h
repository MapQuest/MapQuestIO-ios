//
//  MQLocationManager.h
//  MQIoTiOSSDK
//
//  Created by sehoward15 on 12/8/16.
//  Copyright © 2016 Mapquest. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface MQIOLocationTrackingManager: NSObject

- (nonnull instancetype)initWithClientId:(nonnull NSString *)clientId clientSecret: (nonnull NSString *)clientSecret;
- (nonnull instancetype)init NS_UNAVAILABLE;

/// Indicates that, when applicable, speed should be reported. Setting this property to YES will result in increased battery usage. When set to know there are no guarantees location observation will return a valid speed. It is recommended that a `speedThreshold` is set indicating an appropriate value that speed should begin tracking. Default value is YES.
@property (assign) BOOL trackSpeed;
/// The threshold in which speed should begin reporting. Speed below this threshold may be ignored and return a -1.0 indicating that location services is tracking in a low battery mode. By default it is set to 10 m/s or roughly 20 mph (~32kph). This property is ignored when `trackSpeed` is disabled.
@property (assign) NSInteger speedThreshold;


/**
 How often a report is sent. Lowering the time to send will result in more radio usage when the device is moving. Don't lower this value unless there is a specific value to your customers. Setting this value lower will not immediately take effect if observations are currently batched to be sent at a later time.

 @param reportingFrequency Time interval to send report. Default is 60 seconds.
 */
- (void)setReportingFrequency:(NSTimeInterval)reportingFrequency;

/// Starts tracking the user's location.
- (void)startTracking;
/// Stop all location services.
- (void)stopTracking;

@end

