//
//  MQPlatformSDK.h
//  MQPlatformSDK
//
//  Created by sehoward15 on 1/11/17.
//  Copyright © 2017 Mapquest. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MQPlatformSDK.
FOUNDATION_EXPORT double MapQuestIOVersionNumber;

//! Project version string for MQPlatformSDK.
FOUNDATION_EXPORT const unsigned char MapQuestIOVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MQPlatformSDK/PublicHeader.h>

#import <MapQuestIO/MQIOPlatformAPI.h>
#import <MapQuestIO/MQIOLocationTrackingManager.h>
#import <MapQuestIO/MQIORegionManager.h>
#import <MapQuestIO/MQIOObservation.h>
#import <MapQuestIO/MQIOShareObserver.h>
