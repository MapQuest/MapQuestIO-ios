//
//  PlatformAPI.h
//  MQIoTiOSSDK
//
//  Created by sehoward15 on 12/19/16.
//  Copyright © 2016 Mapquest. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ReporterProtocol.h"

@class MQIOObservation, CLLocation;
@interface MQIOPlatformAPI : NSObject

@property (readonly, nullable) NSString *clientId;
@property (readonly, nullable) NSString *accessToken;

@end

@interface MQIOPlatformAPI (Devices)

/**
 Report the device's location.
 
 @param locations An array of locations ordered by newest to oldest.
 @param completion Data or an error on failure.
 */
+ (void)reportLocations:(nonnull NSArray <CLLocation *> *)locations completion:(void (^ _Nullable)(NSData * _Nullable, NSError * _Nullable, NSInteger))completion
NS_SWIFT_NAME(report(locations:completion:));

/**
 Report a device's observation.

 @param observations An array of observations ordered by newest to oldest.
 @param completion Data or an error on failure.
 */
+ (void)reportObservations:(nonnull NSArray <MQIOObservation *> *)observations completion:(void (^ _Nullable)(NSData * _Nullable, NSError * _Nullable, NSInteger))completion
NS_SWIFT_NAME(report(observations:completion:));

@end

@interface MQIOPlatformAPI (Rules)

/**
 Adding a session returns a UUID used to reference the session for updates and reads using the default timeout (10 mins).
 
 @param completion Returns a *share Id* or error.
 */
+ (void)createShareSession:(void (^ _Nullable)(NSString * _Nullable, NSError * _Nullable, NSInteger))completion;

/**
 Adding a session returns a UUID used to reference the session for updates and reads.
 
 @param timeout How long the share session should last.
 @param completion Returns a *share Id* or error.
 */
+ (void)createShareSessionWithDuration:(int)timeout completion:(void (^ _Nullable)(NSString * _Nullable, NSError * _Nullable, NSInteger))completion;

/**
 Get all observations for a share session. A share session can potentially have a large amount of data and is recommended to call only if all observations are needed. Otherwise consider using retrieveObservationsWithShareId:afterTime:completion:.
 
 @param shareId The *share session* id.
 @param completion All observations are returned in oldest-to-newest order or an error.
 */
+ (void)retrieveObservationsWithShareId:(nonnull NSString *)shareId completion:(void (^ _Nullable)(NSArray <MQIOObservation *> * _Nullable, NSError * _Nullable, NSInteger))completion;


/**
 Get observations for a share session from a time in the past to now.

 @param shareId The *share session* id.
 @param modifiedTimeSince1970 The time to start retrieving observations. Passing in zero results in all observations for this share.
 @param completion All observations are returned in oldest-to-newest order or an error.
 */
+ (void)retrieveObservationsWithShareId:(nonnull NSString *)shareId fromTime:(NSInteger)modifiedTimeSince1970 completion:(void (^ _Nullable)(NSArray<MQIOObservation *> * _Nullable, NSError * _Nullable, NSInteger))completion;


@end

